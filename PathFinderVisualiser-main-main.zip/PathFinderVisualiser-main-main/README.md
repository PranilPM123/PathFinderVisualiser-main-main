# OPTIPATH

**Interactive Pathfinding Algorithm Visualizer**

A comprehensive web application that demonstrates and visualizes fundamental pathfinding algorithms in real-time. This project showcases the implementation of classic graph traversal algorithms with an intuitive, interactive interface that makes complex computer science concepts accessible and engaging.

## Project Summary

OptiPath is a full-stack web application built with **Node.js**, **Express.js**, and **vanilla JavaScript** that provides real-time visualization of pathfinding algorithms. The application features a responsive grid-based interface where users can interactively create mazes, place obstacles, and observe how different algorithms navigate from start to finish nodes.

**Key Features:**
- Real-time algorithm visualization with adjustable speeds
- Interactive grid manipulation (draw walls, add weights, place obstacles)
- Responsive design supporting mobile, tablet, and desktop
- Multiple maze generation algorithms and pattern demonstrations
- Educational tool for understanding algorithm efficiency and behavior

## Meet the Algorithms

This application supports the following algorithms: 

**Dijkstra's Algorithm** (weighted): the father of pathfinding algorithms; guarantees the shortest path

**A* Search** (weighted): arguably the best pathfinding algorithm; uses heuristics to guarantee the shortest path much faster than Dijkstra's Algorithm

**Breath-first Search** (unweighted): a great algorithm; guarantees the shortest path

**Depth-first Search** (unweighted): a very bad algorithm for pathfinding; does not guarantee the shortest path.

## How does it works

Initially you will be displayed with an empty 2-dimensional grid with the start and finish nodes. They are where the search starts and finishes respectively and are displayed by the person and the treasure chest icons. You can use the buttons in the navbar to create random walls and clear them. On desktop, you can also use the cursor on the empty squares/nodes and drag it to draw walls. You can also move the start and finish nodes around by clicking and dragging. Once you are happy with the grid, you can select an algorithm and start visualising!

You will see the green nodes slowly fill up the adjacent nodes in the grid - this is the searching part. Once the green nodes find the finish node, then the yellow nodes will display the path the algorithm chose to get there. Note that this is not always the shortest path for Depth-first search. It is the shortest path for some algorithms however (like Dijkstra's and Breadth-first search).

## Features

**Responsive design for the grid and components try it out on mobile, tablet and desktop!**

**Can generate random walls or draw them**

**Can drag the start and finish (on desktop)**

## Technical Stack

- **Frontend**: HTML5, CSS3, JavaScript (ES6+), Bootstrap 3.3.7
- **Backend**: Node.js with Express.js
- **Architecture**: Client-server model with RESTful endpoints
- **Build Tools**: Watchify for bundling, Nodemon for development

## Getting Started

1. Clone the repository
2. Install dependencies: `npm install`
3. Start the server: `npm start`
4. Open `http://localhost:1337` in your browser

## Author

**Your Name** - Software Development Engineer

This project demonstrates proficiency in:
- Algorithm implementation and optimization
- Full-stack web development
- Interactive UI/UX design
- Computer science fundamentals
- Performance optimization techniques

---

*Built with ❤️ for learning and demonstrating pathfinding algorithms*

